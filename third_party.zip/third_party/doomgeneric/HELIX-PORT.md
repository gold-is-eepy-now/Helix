# DoomGeneric source and Helix port status

The vendored files in this directory come from [ozkl/doomgeneric](https://github.com/ozkl/doomgeneric), upstream revision `e257a09527062bfb986b6e5e0780839b6cbd5b71` (2026-10-18 checkout). The upstream `LICENSE` applies to this code. DoomGeneric is GPL-2.0-or-later; Helix has permission from its maintainer to include/link this engine.

This is a source import, not a working game port yet. Helix does not have a filesystem or hosted C runtime, and the engine still needs platform hooks for frame presentation, keyboard events, timing, allocation, and WAD access. Helix now has framebuffer presentation and key events, and it can pass a locally supplied IWAD as a Limine module. The in-memory Doom WAD accessor is `kernel/src/doom_wad.h`. The remaining engine integration is tracked in `ROADMAP.md`.

To include a WAD you are licensed to use in a disk image, build with:

```sh
make DOOM_WAD=/path/to/doom1.wad
```

This places the file at `/boot/doom/doom1.wad` and registers it as a Limine module. The WAD is not included in this repository or image by default.
